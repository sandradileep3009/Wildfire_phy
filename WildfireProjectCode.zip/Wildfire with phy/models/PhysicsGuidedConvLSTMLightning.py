
import torch
from torch.optim import AdamW

from .BaseModel import BaseModel
from .physics_warping.wildfire_convlstm import WildfireConvLSTM


class PhysicsGuidedConvLSTMLightning(BaseModel):

    def __init__(
        self,
        n_channels: int,
        flatten_temporal_dimension: bool,
        pos_class_weight: float,
        loss_function: str = "BCE",
        use_doy: bool = False,
        hidden_channels: int = 64,
        kernel_size: int = 3,
        max_motion: float = 8.0,
        learning_rate: float = 1e-3,
        weight_decay: float = 1e-4,
    ):

        if n_channels != 45:
            raise ValueError(
                f"Physics model requires 45 total input channels, got {n_channels}"
            )

        if flatten_temporal_dimension:
            raise ValueError(
                "Physics ConvLSTM requires flatten_temporal_dimension=False"
            )

        if use_doy:
            raise ValueError(
                "Day-of-year input is not implemented in this model"
            )

        super().__init__(
            n_channels=n_channels,
            flatten_temporal_dimension=False,
            pos_class_weight=pos_class_weight,
            loss_function=loss_function,
            use_doy=False,
            required_img_size=None,
        )

        self.model = WildfireConvLSTM(
            input_channels=40,
            hidden_channels=hidden_channels,
            kernel_size=kernel_size,
            max_motion=max_motion,
        )

        self.learning_rate = learning_rate
        self.weight_decay = weight_decay

    def configure_optimizers(self):

        optimizer = AdamW(
            self.parameters(),
            lr=self.learning_rate,
            weight_decay=self.weight_decay,
        )

        return optimizer

    def predict_step(self, batch, batch_idx, dataloader_idx=0):

        x, y = batch

        # Channel 39 is the binary active-fire mask.
        # Channels 40–44 are the five physics features.
        x_af = x[:, :, 39, :, :]

        y_hat = self(x).squeeze(1)

        return x_af, y, y_hat
