
import torch


def pixel_to_norm(p, size):
    """Convert pixel coordinates to normalized grid coordinates."""
    return 2.0 * p / max(size - 1, 1) - 1.0


def norm_to_pixel(g, size):
    """Convert normalized coordinates to pixel coordinates."""
    return (g + 1.0) * 0.5 * max(size - 1, 1)


def pixel_displacement_to_norm(d, size):
    """Convert pixel displacement to normalized displacement."""
    return 2.0 * d / max(size - 1, 1)
