import torch
import torch.nn as nn


class MotionEstimator(nn.Module):
    """
    Learns displacement between consecutive active-fire masks.

    Input:
        previous_mask: [B, 1, H, W]
        current_mask:  [B, 1, H, W]

    Output:
        displacement: [B, 2, H, W] in pixel units (dx, dy)
    """

    def __init__(self, hidden_channels=32, max_displacement=8.0):
        super().__init__()

        self.max_displacement = max_displacement

        self.encoder = nn.Sequential(
            nn.Conv2d(3, hidden_channels, 3, padding=1),
            nn.ReLU(inplace=True),

            nn.Conv2d(
                hidden_channels,
                hidden_channels,
                3,
                padding=2,
                dilation=2
            ),
            nn.ReLU(inplace=True),

            nn.Conv2d(
                hidden_channels,
                hidden_channels,
                3,
                padding=4,
                dilation=4
            ),
            nn.ReLU(inplace=True),

            nn.Conv2d(hidden_channels, 2, kernel_size=3, padding=1)
        )

        # Start with zero estimated motion.
        final_layer = self.encoder[-1]
        nn.init.zeros_(final_layer.weight)
        nn.init.zeros_(final_layer.bias)

    def forward(self, previous_mask, current_mask):
        motion_input = torch.cat(
            [
                previous_mask,
                current_mask,
                current_mask - previous_mask
            ],
            dim=1
        )

        displacement = self.encoder(motion_input)

        return self.max_displacement * torch.tanh(displacement)