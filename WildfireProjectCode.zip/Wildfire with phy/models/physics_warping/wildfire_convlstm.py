import torch
import torch.nn as nn

from .motion_estimator import MotionEstimator
from .physics_guided_warp import PhysicsGuidedWarp


class ConvLSTMCell(nn.Module):
    def __init__(self, input_channels, hidden_channels, kernel_size=3):
        super().__init__()

        padding = kernel_size // 2

        self.hidden_channels = hidden_channels

        self.gates = nn.Conv2d(
            input_channels + hidden_channels,
            4 * hidden_channels,
            kernel_size=kernel_size,
            padding=padding
        )

    def forward(self, x, hidden, cell):
        combined = torch.cat([x, hidden], dim=1)
        gates = self.gates(combined)

        i, f, o, g = torch.chunk(gates, 4, dim=1)

        i = torch.sigmoid(i)
        f = torch.sigmoid(f)
        o = torch.sigmoid(o)
        g = torch.tanh(g)

        cell = f * cell + i * g
        hidden = o * torch.tanh(cell)

        return hidden, cell


class WildfireConvLSTM(nn.Module):
    """
    Physics-guided ConvLSTM for WildfireSpreadTS.

    Input:
        x: [B, T, 45, H, W]

    Channels:
        0:40  = original preprocessed WildfireSpreadTS features
        39    = binary active-fire mask
        40:45 = physics channels

    Output:
        logits: [B, 1, H, W]
    """

    def __init__(
        self,
        input_channels=40,
        hidden_channels=64,
        kernel_size=3,
        max_motion=8.0
    ):
        super().__init__()

        self.input_channels = input_channels
        self.hidden_channels = hidden_channels

        self.mask_channel = 39
        self.physics_start = input_channels

        self.motion_estimator = MotionEstimator(
            hidden_channels=32,
            max_displacement=max_motion
        )

        self.physics_warp = PhysicsGuidedWarp(
            hidden_channels=hidden_channels,
            physics_channels=5
        )

        self.convlstm = ConvLSTMCell(
            input_channels=input_channels,
            hidden_channels=hidden_channels,
            kernel_size=kernel_size
        )

        self.output_head = nn.Sequential(
            nn.Conv2d(hidden_channels, 32, kernel_size=3, padding=1),
            nn.ReLU(inplace=True),
            nn.Conv2d(32, 1, kernel_size=1)
        )

    def forward(self, x):
        if x.ndim != 5:
            raise ValueError(
                f"Expected [B,T,C,H,W], received {tuple(x.shape)}"
            )

        B, T, C, H, W = x.shape

        expected_channels = self.input_channels + 5

        if C != expected_channels:
            raise ValueError(
                f"Expected {expected_channels} channels "
                f"({self.input_channels} data + 5 physics), got {C}"
            )

        hidden = x.new_zeros(B, self.hidden_channels, H, W)
        cell = x.new_zeros(B, self.hidden_channels, H, W)

        previous_mask = None

        for t in range(T):
            frame = x[:, t, :self.input_channels]

            current_mask = frame[
                :, self.mask_channel:self.mask_channel + 1
            ]

            physics = x[:, t, self.physics_start:self.physics_start + 5]

            if previous_mask is not None:
                learned_displacement = self.motion_estimator(
                    previous_mask,
                    current_mask
                )

                hidden, displacement = self.physics_warp(
                    hidden,
                    learned_displacement,
                    physics
                )

                # Warp the cell state with the same displacement.
                from .physics_guided_warp import warp_features
                cell = warp_features(cell, displacement)

            hidden, cell = self.convlstm(frame, hidden, cell)

            previous_mask = current_mask

        return self.output_head(hidden)