import torch
import torch.nn as nn
import torch.nn.functional as F


def pixel_to_norm(p, size):
    return 2.0 * p / max(size - 1, 1) - 1.0


def warp_features(features, displacement):
    """
    features:      [B, C, H, W]
    displacement:  [B, 2, H, W], in pixels (dx, dy)

    Uses backward sampling. The supplied displacement is an
    approximate inverse of the forward motion field.
    """
    B, C, H, W = features.shape

    ys, xs = torch.meshgrid(
        torch.arange(H, device=features.device, dtype=features.dtype),
        torch.arange(W, device=features.device, dtype=features.dtype),
        indexing="ij"
    )

    # Backward sampling approximation: sample from p - displacement.
    sample_x = xs.unsqueeze(0) - displacement[:, 0]
    sample_y = ys.unsqueeze(0) - displacement[:, 1]

    grid_x = pixel_to_norm(sample_x, W)
    grid_y = pixel_to_norm(sample_y, H)

    grid = torch.stack((grid_x, grid_y), dim=-1)

    return F.grid_sample(
        features,
        grid,
        mode="bilinear",
        padding_mode="border",
        align_corners=True
    )


class PhysicsGuidedWarp(nn.Module):
    """
    Physics channels:
      0: wind X component
      1: wind Y component
      2: terrain slope
      3: terrain aspect X component
      4: terrain aspect Y component
    """

    def __init__(
        self,
        hidden_channels,
        physics_channels=5,
        gate_hidden=32,
        max_wind_displacement=3.0,
        max_terrain_displacement=2.0,
        max_total_displacement=12.0
    ):
        super().__init__()

        self.max_wind_displacement = max_wind_displacement
        self.max_terrain_displacement = max_terrain_displacement
        self.max_total_displacement = max_total_displacement

        self.gate_net = nn.Sequential(
            nn.Conv2d(
                hidden_channels + physics_channels,
                gate_hidden,
                kernel_size=3,
                padding=1
            ),
            nn.ReLU(inplace=True),
            nn.Conv2d(gate_hidden, 2, kernel_size=1),
            nn.Sigmoid()
        )

        # Learnable strengths, initialized conservatively.
        self.wind_strength = nn.Parameter(torch.tensor(-1.0))
        self.terrain_strength = nn.Parameter(torch.tensor(-1.0))

    def forward(self, hidden, learned_displacement, physics):
        """
        hidden:              [B, hidden_channels, H, W]
        learned_displacement:[B, 2, H, W]
        physics:             [B, 5, H, W]
        """
        if physics.shape[1] != 5:
            raise ValueError(
                f"Expected 5 physics channels, got {physics.shape[1]}"
            )

        gates = self.gate_net(torch.cat([hidden, physics], dim=1))

        wind = physics[:, 0:2]
        slope = physics[:, 2:3].clamp(0.0, 1.0)
        terrain_direction = physics[:, 3:5]

        wind_displacement = (
            self.max_wind_displacement
            * torch.sigmoid(self.wind_strength)
            * gates[:, 0:1]
            * wind
        )

        terrain_displacement = (
            self.max_terrain_displacement
            * torch.sigmoid(self.terrain_strength)
            * gates[:, 1:2]
            * slope
            * terrain_direction
        )

        displacement = (
            learned_displacement
            + wind_displacement
            + terrain_displacement
        )

        displacement = displacement.clamp(
            -self.max_total_displacement,
            self.max_total_displacement
        )

        warped_hidden = warp_features(hidden, displacement)

        return warped_hidden, displacement